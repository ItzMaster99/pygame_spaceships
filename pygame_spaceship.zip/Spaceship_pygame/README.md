# PygameForBeginners
A simple 2D python game designed to teach you the pygame module.
